To compile the BatteryChecker use: g++ -mwindows -luser32 -o battery_checker.exe battery_checker.cpp
To compile the setup, just use: csc BatteryCheckerSetup.cs