To install the BatteryChecker please start the BatteryCheckerSetup


If you accidentaly started the BatteryChecker don't start the Setup!
Run this command in the Administartor cmd: taskkill /f /im BatteryChecker.exe
Now you can start the Setup.